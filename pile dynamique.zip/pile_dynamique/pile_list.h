#include "list.h"

typedef liste pile;

void init(pile *p);
int sommet(pile p);

void afficher(pile p );

int push(pile *p,int x);

int pull(pile *p);

