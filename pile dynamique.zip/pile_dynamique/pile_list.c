#include <stdio.h>
#include <stdlib.h>
#include "pile_list.h"




int sommet(pile p){
   elem *elem = p.first;
   return elem->data;
}


int push(pile *p,int x){
        int a= ajouter_debut(p,x);
         return a;
}

int pull(pile *p){
    int a= supprimer_debut(p);
         return a;
}
