#include <stdio.h>
#include <stdlib.h>

#include "pile_list.h"



int main()
{
    printf("pile dynamique \n");

    pile p;

    init(&p);
    afficher(p);

    push(&p,10);
    afficher(p);

    push(&p,20);
    afficher(p);

    push(&p,30);
    afficher(p);

    pull(&p);
    afficher(p);

    pull(&p);
    afficher(p);


    return 0;
}
